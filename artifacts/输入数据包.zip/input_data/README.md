# 多租户功能开关发布材料

configs/base_flags.json保存功能开关基线。changes/patch_queue.jsonl按行记录待发布变更。policy/tenant_policy.csv给出租户版本和灰度上限，policy/approvals.csv保存审批状态，policy/release_contract.json定义本批裁决顺序、原因代码和输出合同。

把starter/compile_release.mjs复制到output/src/compile_release.mjs并完成实现。在input_data目录运行：

    npm run release

运行入口会在临时目录调用候选源码，成功后更新output/reports和output/configs。候选源码以input_data目录和临时输出目录为参数。执行失败时不会保留本轮报告与配置。
