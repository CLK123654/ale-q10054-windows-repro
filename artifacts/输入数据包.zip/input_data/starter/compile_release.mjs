import fs from "node:fs";
import path from "node:path";

const inputRoot = path.resolve(process.argv[2] ?? ".");
const outputRoot = path.resolve(process.argv[3] ?? "output");

// 在这里读取发布输入并生成租户级裁决、配置和摘要。
fs.mkdirSync(path.join(outputRoot, "reports"), { recursive: true });
throw new Error(`尚未完成发布编排：${inputRoot}`);
