import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import process from "node:process";
import { fileURLToPath } from "node:url";
import { spawnSync } from "node:child_process";

const toolsDir = path.dirname(fileURLToPath(import.meta.url));
const inputRoot = path.resolve(toolsDir, "..");
const outputRoot = path.join(inputRoot, "output");
const source = path.join(outputRoot, "src", "compile_release.mjs");
const published = ["reports", "configs"];

function removePublished() {
  for (const name of published) {
    fs.rmSync(path.join(outputRoot, name), { recursive: true, force: true });
  }
}

function stop(message, code = 1) {
  removePublished();
  console.error(message);
  process.exit(code);
}

if (!fs.existsSync(source)) stop(`缺少发布编排源码：${source}`, 2);

removePublished();
const stagingRoot = fs.mkdtempSync(path.join(os.tmpdir(), "tenant-release-"));
try {
  const run = spawnSync(process.execPath, [source, inputRoot, stagingRoot], {
    cwd: inputRoot,
    encoding: "utf8",
    timeout: 30_000,
    windowsHide: true,
  });
  if (run.error) stop(`无法执行发布编排源码：${run.error.message}`, 3);
  if (run.status !== 0) {
    if (run.stdout) process.stdout.write(run.stdout);
    if (run.stderr) process.stderr.write(run.stderr);
    stop(`发布编排源码退出码为${run.status}`, run.status || 4);
  }
  for (const name of published) {
    const staged = path.join(stagingRoot, name);
    if (!fs.existsSync(staged)) stop(`发布编排源码没有生成${name}`, 5);
    fs.renameSync(staged, path.join(outputRoot, name));
  }
  console.log("Tenant feature release completed");
} catch (error) {
  stop(error.stack ?? String(error), 6);
} finally {
  fs.rmSync(stagingRoot, { recursive: true, force: true });
}
